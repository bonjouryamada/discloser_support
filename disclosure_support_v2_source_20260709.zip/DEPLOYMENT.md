# V2 Deployment

## 必要な確認情報

公開前に、次の情報を確定してください。

1. 現行Streamlitアプリが接続されているGitHubリポジトリURL、ブランチ、実行ファイルパス
2. 現行サイトをV2へ置き換えるか、別URLで先行公開するか
3. 正式なサイト名、運営者名、問い合わせ先
4. プライバシーポリシー・利用規約の掲載要否
5. EDINET APIキーを現行アプリから引き継ぐか

APIキーや`.env`はGitHubへコミットしないでください。

## 現在のローカル受入状況

- 確認日: 2026-07-09
- 単体テスト: `.\.venv\Scripts\python.exe -m unittest discover -s tests -v` が 11 tests OK
- ローカルブラウザQA: PC幅と390px幅で主要導線 OK
- 未完了: GitHub/Streamlit配置、Secrets登録、実EDINET API結合、法令本文差分精査、運営者情報確定

## 推奨公開手順

1. `web_v2`の内容をGitHubのV2用ブランチへ配置する。
2. Streamlit Community Cloudで新しいテストアプリを作り、実行ファイルを`app.py`にする。
3. App settingsのSecretsへ`EDINET_API_KEY`を設定する。
4. 検索、全101項目、手動レビュー表示、EDINET取得、Excel出力を確認する。
5. 法令・JPX規則の現行版との差分確認後、現行アプリをV2へ切り替える。

## 公開前チェック

- `.env`、APIキー、個人情報がリポジトリに含まれていない
- 101項目、6区分、manual 13件が維持されている
- 「該当記載なし」を「非該当」と誤認させない
- 運営者・問い合わせ先・更新日を表示する
- PCとスマートフォンで主要操作を確認する
